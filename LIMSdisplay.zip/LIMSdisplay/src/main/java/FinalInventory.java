
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class FinalInventory extends javax.swing.JFrame {
    
private TableManager tableman;

private String[] sections = {"Circulation", "Reference", "Filipiniana", "American Corner"};
int circ_no_data = 0;
int circ_no_scan = 0;
int ref_no_data = 0;
int ref_no_scan = 0; 
int fili_no_data = 0;
int fili_no_scan = 0;
int ac_no_data = 0;
int ac_no_scan = 0;
    
    public FinalInventory() throws SQLException {
        initComponents();
        getBooks();
        displayResults();
        loadBooks();
        getDateTime();
        setExtendedState(JFrame.MAXIMIZED_BOTH);   
    }

    private void loadBooks() throws SQLException{
        tableman = new TableManager(booklist_final_inv);
        DBConfig dbcon = new DBConfig();
        tableman.addBookFinal();
    } 

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        circ_miss = new javax.swing.JLabel();
        circ_database = new javax.swing.JLabel();
        circ_scan = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        ref_database = new javax.swing.JLabel();
        ref_scan = new javax.swing.JLabel();
        ref_miss = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        fili_database = new javax.swing.JLabel();
        fili_scan = new javax.swing.JLabel();
        fili_miss = new javax.swing.JLabel();
        ac_miss = new javax.swing.JLabel();
        ac_scan = new javax.swing.JLabel();
        ac_database = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        total_database = new javax.swing.JLabel();
        total_scan = new javax.swing.JLabel();
        total_miss = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        booklist_final_inv = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N
        jLabel1.setText("Library Inventory Mobile Scanner");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, -1, -1));

        jLabel2.setFont(new java.awt.Font("Arial Narrow", 1, 24)); // NOI18N
        jLabel2.setText("Final Inventory Report");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 50, -1, -1));

        jLabel3.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        jLabel3.setText("S.Y. 2019 - 2020");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 80, -1, -1));

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Arial Narrow", 1, 24)); // NOI18N
        jLabel4.setText("Inventory Totals:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, -1, -1));

        jLabel5.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel5.setText("Circulation:");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, -1, -1));

        circ_miss.setFont(new java.awt.Font("Arial Narrow", 0, 18)); // NOI18N
        circ_miss.setText("Copies missing/unscanned:");
        jPanel1.add(circ_miss, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 90, -1, -1));

        circ_database.setFont(new java.awt.Font("Arial Narrow", 0, 18)); // NOI18N
        circ_database.setText("Copies in database:");
        jPanel1.add(circ_database, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, -1, -1));

        circ_scan.setFont(new java.awt.Font("Arial Narrow", 0, 18)); // NOI18N
        circ_scan.setText("Copies scanned:");
        jPanel1.add(circ_scan, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 70, -1, -1));

        jLabel9.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel9.setText("Reference:");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, -1, -1));

        ref_database.setFont(new java.awt.Font("Arial Narrow", 0, 18)); // NOI18N
        ref_database.setText("Copies in database:");
        jPanel1.add(ref_database, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 140, -1, -1));

        ref_scan.setFont(new java.awt.Font("Arial Narrow", 0, 18)); // NOI18N
        ref_scan.setText("Copies scanned:");
        jPanel1.add(ref_scan, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 160, -1, -1));

        ref_miss.setFont(new java.awt.Font("Arial Narrow", 0, 18)); // NOI18N
        ref_miss.setText("Copies missing/unscanned:");
        jPanel1.add(ref_miss, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 180, -1, -1));

        jLabel13.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel13.setText("Filipiniana:");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 30, -1, -1));

        fili_database.setFont(new java.awt.Font("Arial Narrow", 0, 18)); // NOI18N
        fili_database.setText("Copies in database:");
        jPanel1.add(fili_database, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 50, -1, -1));

        fili_scan.setFont(new java.awt.Font("Arial Narrow", 0, 18)); // NOI18N
        fili_scan.setText("Copies scanned:");
        jPanel1.add(fili_scan, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 70, -1, -1));

        fili_miss.setFont(new java.awt.Font("Arial Narrow", 0, 18)); // NOI18N
        fili_miss.setText("Copies missing/unscanned:");
        jPanel1.add(fili_miss, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 90, -1, -1));

        ac_miss.setFont(new java.awt.Font("Arial Narrow", 0, 18)); // NOI18N
        ac_miss.setText("Copies missing/unscanned:");
        jPanel1.add(ac_miss, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 180, -1, -1));

        ac_scan.setFont(new java.awt.Font("Arial Narrow", 0, 18)); // NOI18N
        ac_scan.setText("Copies scanned:");
        jPanel1.add(ac_scan, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 160, -1, -1));

        ac_database.setFont(new java.awt.Font("Arial Narrow", 0, 18)); // NOI18N
        ac_database.setText("Copies in database:");
        jPanel1.add(ac_database, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 140, -1, -1));

        jLabel20.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel20.setText("American Corner:");
        jPanel1.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 120, -1, -1));

        jLabel21.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel21.setText("TOTAL:");
        jPanel1.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 210, -1, -1));

        total_database.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        total_database.setText("Copies in database:");
        jPanel1.add(total_database, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 230, -1, -1));

        total_scan.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        total_scan.setText("Copies scanned:");
        jPanel1.add(total_scan, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 250, -1, -1));

        total_miss.setFont(new java.awt.Font("Arial Narrow", 1, 18)); // NOI18N
        total_miss.setText("Copies missing/unscanned:");
        jPanel1.add(total_miss, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 270, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 690, 300));

        booklist_final_inv.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Title Statement", "Call Number", "Barcode"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(booklist_final_inv);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 450, 690, 130));

        jButton1.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 14)); // NOI18N
        jButton1.setText("Generate Excel File");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 710, 260, 50));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    try {
        excelGen();
    } catch (IOException ex) {
        Logger.getLogger(FinalInventory.class.getName()).log(Level.SEVERE, null, ex);
    } catch (SQLException ex) {
        Logger.getLogger(FinalInventory.class.getName()).log(Level.SEVERE, null, ex);
    }
    }//GEN-LAST:event_jButton1ActionPerformed


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FinalInventory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FinalInventory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FinalInventory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FinalInventory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new FinalInventory().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(FinalInventory.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ac_database;
    private javax.swing.JLabel ac_miss;
    private javax.swing.JLabel ac_scan;
    private javax.swing.JTable booklist_final_inv;
    private javax.swing.JLabel circ_database;
    private javax.swing.JLabel circ_miss;
    private javax.swing.JLabel circ_scan;
    private javax.swing.JLabel fili_database;
    private javax.swing.JLabel fili_miss;
    private javax.swing.JLabel fili_scan;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel ref_database;
    private javax.swing.JLabel ref_miss;
    private javax.swing.JLabel ref_scan;
    private javax.swing.JLabel total_database;
    private javax.swing.JLabel total_miss;
    private javax.swing.JLabel total_scan;
    // End of variables declaration//GEN-END:variables

    private void getBooks() throws SQLException {
        for (String section : sections) {
            ArrayList<Book> books = new DBConfig().getBooks(section);             //step 2 and 3 (get books from db by section; place books in list)
            for (Book book : books) {                   //step 4 (iterate through the list of books)
                switch (section) {
                    case "Circulation":
                        circ_no_data = circ_no_data + book.getTotal_no();
                        circ_no_scan = circ_no_scan + book.getScanned_no();
                        break;
                    case "Reference":
                        ref_no_data = ref_no_data + book.getTotal_no();
                        ref_no_scan = ref_no_scan + book.getScanned_no();
                        break;
                    case "Filipiniana":
                        fili_no_data = fili_no_data + book.getTotal_no();
                        fili_no_scan = fili_no_scan + book.getScanned_no();
                        break;
                    case "American Corner":
                        ac_no_data = ac_no_data + book.getTotal_no();
                        ac_no_scan = ac_no_scan + book.getScanned_no();
                        break;
                }
            }
        }
        
    }

    private void displayResults() {
        int circ_no_miss = circ_no_data - circ_no_scan;
        circ_database.setText("Copies in database: " + String.valueOf(circ_no_data));
        circ_scan.setText("Copies scanned: " + String.valueOf(circ_no_scan));
        circ_miss.setText("Copies missing/unscanned: " + String.valueOf(circ_no_miss));
        
        int ref_no_miss = ref_no_data - ref_no_scan;
        ref_database.setText("Copies in database: " + String.valueOf(ref_no_data));
        ref_scan.setText("Copies scanned: " + String.valueOf(ref_no_scan));
        ref_miss.setText("Copies missing/unscanned: " + String.valueOf(ref_no_miss));
        
        int fili_no_miss = fili_no_data - fili_no_scan;
        fili_database.setText("Copies in database: " + String.valueOf(fili_no_data));
        fili_scan.setText("Copies scanned: " + String.valueOf(fili_no_scan));
        fili_miss.setText("Copies missing/unscanned: " + String.valueOf(fili_no_miss));
        
        int ac_no_miss = ac_no_data - ac_no_scan;
        ac_database.setText("Copies in database: " + String.valueOf(ac_no_data));
        ac_scan.setText("Copies scanned: " + String.valueOf(ac_no_scan));
        ac_miss.setText("Copies missing/unscanned: " + String.valueOf(ac_no_miss));
        
        int total_no_data = circ_no_data + ref_no_data + fili_no_data + ac_no_data;
        int total_no_scan = circ_no_scan + ref_no_scan + fili_no_scan + ac_no_scan;
        int total_no_miss = circ_no_miss + ref_no_miss + fili_no_miss + ac_no_miss;
        total_database.setText("Copies in database: " + String.valueOf(total_no_data));
        total_scan.setText("Copies scanned: " + String.valueOf(total_no_scan));
        total_miss.setText("Copies missing/unscanned: " + String.valueOf(total_no_miss));
        
    }
    
    private void getDateTime(){
        DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
        String dateTime = dateFormat.format(new Date());
        
        jLabel3.setText(dateTime);
    }
    
    private void excelGen() throws FileNotFoundException, IOException, SQLException {
        String[] columns = {"Barcode", "Title", "Call number", "Section"};
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Missing Books");
        Row headerRow = sheet.createRow(0);
        
        for(int i = 0; i < columns.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(columns[i]);
        }
        
        int rowNum = 1;
        
        ArrayList<Book> books = new DBConfig().getBooks("All sections");
        ArrayList<Barcode> barcodes = new DBConfig().getBarcodes();
        for (Book book : books) {
            for (Barcode barcode : barcodes) {
                if (book.getId() == barcode.getBook_id() && !barcode.isIs_Scanned()){
                    Row row = sheet.createRow(rowNum++);
                    row.createCell(0).setCellValue(barcode.getBarcode());
                    row.createCell(1).setCellValue(book.getTitle());
                    row.createCell(2).setCellValue(book.getCall_no());
                    row.createCell(3).setCellValue(book.getSection());
                }               
            }
        }
        
        for(int i = 0; i < columns.length; i++) {
            sheet.autoSizeColumn(i);
        }
        
        FileOutputStream fileOut = new FileOutputStream("Final Inventory.xlsx");
        System.out.println("Excel File Generated!");
        workbook.write(fileOut);
        fileOut.close();
        
        workbook.close();
    }
}
