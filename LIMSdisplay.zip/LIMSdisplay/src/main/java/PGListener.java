
import com.impossibl.postgres.api.jdbc.PGConnection;
import com.impossibl.postgres.api.jdbc.PGNotificationListener;
import com.impossibl.postgres.jdbc.PGDataSource;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;
import sun.util.logging.PlatformLogger;


public class PGListener extends Thread{             //Thread is a class; PGListener borrows defined class from thread to use its functions (inheritance); Thread is a class for multithreading
    private BlockingQueue queue;                //for queueing
    private Thread t;                           //object of Thread to use for listening
    private TableManager tm;                    //defined object; to update table
    private String mode;
    
    PGConnection connection;                    //to connect with database (same with dbconfig)
    
    public PGListener(TableManager tm, String mode) {            //connected with Table.java
        this.tm = tm;
        this.mode = mode;
        
        queue = new ArrayBlockingQueue(10);
        
        PGNotificationListener listener = new PGNotificationListener() {                //used for listening update. update is in the form of notification
            @Override           //required function for every new object; if you create the new object, override is needed for the function to have its own implementation (because it has queue.add here)
            public void notification(int processId, String channelName, String payload) {              //notifications are by queues; payload - message
                queue.add("/channels/" + channelName + " " + payload);          //queue.add - puts in the queue; if many are using the android simultaneously, it handles the queue. channel name to determine what trigger happened
            }
        };
        try {
            PGDataSource dataSource = new PGDataSource();
            dataSource.setHost("localhost");
            dataSource.setPort(5432);
            dataSource.setDatabaseName("db_inventory");
            dataSource.setUser("postgres");
            dataSource.setPassword("pgadmin");
            
            connection = (PGConnection) dataSource.getConnection();
            
            connection.addNotificationListener(listener);
            
            Statement statement = connection.createStatement();
            statement.execute("LISTEN q_event");
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public BlockingQueue getQueue() {
        return queue;
    }
    
    public void run() {
        BlockingQueue queue = this.getQueue();              //get the queue
        
        while (true) {     //for listening; loop forever to listen         
            try {
                String msg = (String) queue.take();
                
                System.out.println(msg);
                
                if (msg != null) {              // there is message, which is the update
                    
                    //insert if else statement for adding books and adding online users
                    
                    
                    if (msg.contains("tbl_inventory") && mode.equals("books")){
                        //if adding books
                        tm = new TableManager(tm.getBook_list_display());
                        tm.addBook(new DBConfig().getBooks("All sections"), new DBConfig().getBarcodes());
                        
                    } 
                    else if (msg.contains("tbl_users") && mode.equals("users")){
                        //else if adding online users
                        tm = new TableManager(tm.getBook_list_display(), tm.getLbl_no_users());
                        System.out.println("users");
                        tm.addUsers(new DBConfig().getOnlineUsers());
                    }
                    
                    else if (msg.contains("tbl_users") && mode.equals("manage")){
                        //else if adding users
                        tm = new TableManager(tm.getBook_list_display());
                        System.out.println("manage");
                        tm.manageUsers(new DBConfig().getUsers());
                    }
       
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (SQLException ex) {
                Logger.getLogger(PGListener.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void start () {
        if (t == null) {
            t = new Thread (this);
            t.start ();
        }
    }
    
}
