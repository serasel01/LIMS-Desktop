
import java.awt.Color;
import java.awt.Component;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ASUS
 */
public class TableManager {
    
    private JTable list_display;
    private JLabel lbl_no_users;

    public TableManager() {
    }

    public TableManager(JTable tbl_online_users, JLabel lbl_no_users) {
         this.list_display = tbl_online_users;
         this.lbl_no_users = lbl_no_users;
    }

    public JTable getBook_list_display() {
        return list_display;
    }

    public void setBook_list_display(JTable book_list_display) {
        this.list_display = book_list_display;
    }

    public JLabel getLbl_no_users() {
        return lbl_no_users;
    }

    public void setLbl_no_users(JLabel lbl_no_users) {
        this.lbl_no_users = lbl_no_users;
    }
    
    public TableManager(JTable book_list_display) {
        this.list_display = book_list_display;
    }
    
    private DefaultTableModel setOnlineTable() {
        DefaultTableModel model = new DefaultTableModel (0, 0);
        String header[] = new String[]{"ID", "Name", "Permission"};
        model.setColumnIdentifiers(header);      //sets the header
        list_display.setModel(model);
        return model;
    }
    
    private DefaultTableModel setUserTable() {
        DefaultTableModel model = new DefaultTableModel (0, 0);
        String header[] = new String[]{"ID", "Name", "Online Status", 
            "Permission"};
        model.setColumnIdentifiers(header);      //sets the header
        list_display.setModel(model);
        return model;
    }
    
    public void addUsers(ArrayList<User> users) {            //arraylist - part of the classes for collection; store objects of that class of the chosen class inserted in "<>"; books - name only
        DefaultTableModel model = setOnlineTable();
        
        for (User user : users) {       //for each - for unknown count in array; for each scans through the whole collection
            Vector<Object> data = new Vector<Object>();
            data.add(user.getId());
            data.add(user.getName());
            
            if(user.isEnabled()){
                data.add("ENABLED");
            
            } else {
                data.add("BLOCKED");
            }
            
            model.addRow(data);
        }
        
        lbl_no_users.setText("Connected Users: " + String.valueOf(users.size()));
    }
    
    public void manageUsers(ArrayList<User> users) {            //arraylist - part of the classes for collection; store objects of that class of the chosen class inserted in "<>"; books - name only
        DefaultTableModel model = setUserTable();
        
        for (User user : users) {       //for each - for unknown count in array; for each scans through the whole collection
            Vector<Object> data = new Vector<Object>();
            data.add(user.getId());
            data.add(user.getName());
            
            if(user.isOnlineStatus()){
                data.add("ONLINE");
            } else {
                data.add("OFFLINE");
            }
            
            if(user.isEnabled()){
                data.add("ENABLED");
            
            } else {
                data.add("BLOCKED");
            }
            
            model.addRow(data);
        }
       
    }
    
    //scan status - "completed", "on progress"
    private DefaultTableModel setTable() {
        DefaultTableModel model = new DefaultTableModel (0, 0);
        String header[] = new String[]{"Barcodes", "Title Statement", "Call Number", "Total Number", "Total Scanned", "Status", "Date & Time Scanned"};
        model.setColumnIdentifiers(header);      //sets the header
        list_display.setModel(model);
        return model;
    }
    
    public void addBook(ArrayList<Book> books, ArrayList<Barcode> barcodes) {            //arraylist - part of the classes for collection; store objects of that class of the chosen class inserted in "<>"; books - name only
        DefaultTableModel model = setTable();
        
        for (Book book : books) {       //for each - for unknown count in array; for each scans through the whole collection
            Vector<Object> data = new Vector<Object>();
            
            String separator = "";
            StringBuilder barcodeBuilder = new StringBuilder();
            StringBuilder timestampBuilder = new StringBuilder();
            
            for (Barcode barcode : barcodes) {              //for each object (object barcode created) which was added in the collection, do code below it
                if (barcode.getBook_id() == book.getId()) {
                    barcodeBuilder.append(separator);
                    barcodeBuilder.append(barcode.getBarcode());
                    
                    timestampBuilder.append(separator);
                    timestampBuilder.append(barcode.getTimestamp());
                    separator = ", ";
                }
            }
            data.add(barcodeBuilder.toString());
            data.add(book.getTitle());
            data.add(book.getCall_no());
            data.add(book.getTotal_no());
            data.add(book.getScanned_no());
            
            if (book.getScanned_no() < book.getTotal_no()) {
                data.add("");
            }
            else {
                data.add("COMPLETE");
            }
            
            data.add(timestampBuilder.toString());
            model.addRow(data);
        }
        
        list_display.setDefaultRenderer(Object.class, new SetCellRenderer());
        
    }
    
    private static class SetCellRenderer implements TableCellRenderer {
        private DefaultTableCellRenderer renderer =  new DefaultTableCellRenderer();

        public SetCellRenderer() {
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, 
                Object value, boolean isSelected, boolean hasFocus, int row, 
                int column) {
            Component c = renderer.getTableCellRendererComponent(table, value, 
                    hasFocus, hasFocus, row, column);
            
            //changes color when that row is selected
            if(isSelected){
                    c.setBackground(Color.YELLOW);
                    c.setForeground(Color.BLACK);

            //alternates color each row by default
            } else {
                if (row%2 == 0){
                    c.setBackground(Color.WHITE);

                }
                else {
                    c.setBackground(Color.CYAN);
                }     
            }
            

///////////CHANGE THE "PUBLISHED?" to whatever you named in the header
       
            if(table.getColumnModel().getColumn(column).getIdentifier()
                    .equals("Status")){
                if(value.toString().equals("COMPLETE")){
                    c.setBackground(Color.GREEN);
                }
                else {
                    c.setBackground(Color.RED);
                }
            }
            
            return c;
        }
    }
    
    private DefaultTableModel setTableFinal() {
        DefaultTableModel finalmodel = new DefaultTableModel (0, 0);
        String header[] = new String[]{"Title Statement", "Call Number", "Barcode", "Section"};
        finalmodel.setColumnIdentifiers(header);      //sets the header
        list_display.setModel(finalmodel);
        return finalmodel;
    }
    
    public void addBookFinal() throws SQLException {            //arraylist - part of the classes for collection; store objects of that class of the chosen class inserted in "<>"; books - name only
        DefaultTableModel model = setTableFinal();
        
        ArrayList<Book> books = new DBConfig().getBooks("All sections");
        ArrayList<Barcode> barcodes = new DBConfig().getBarcodes();
        
        for (Book book : books) {       //for each - for unknown count in array; for each scans through the whole collection
            for (Barcode barcode : barcodes) {
                if (book.getId() == barcode.getBook_id() && !barcode.isIs_Scanned())
                {
                    Vector<Object> data = new Vector<Object>();

                    data.add(book.getTitle());
                    data.add(book.getCall_no());
                    data.add(barcode.getBarcode());
                    data.add(book.getSection());
            
                    model.addRow(data);
                }
            }
            
        }
        
    }
    
    
}
