
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

public class IntroSession extends javax.swing.JFrame {
    private TableManager tm;
    private PGListener listener;

    public IntroSession() throws UnknownHostException, SQLException {
        initComponents();
        showIP();     
        showOnlineUsers();  
        setExtendedState(getExtendedState() | JFrame.MAXIMIZED_BOTH);
        
        listener = new PGListener(tm, "users");
        listener.start();
    }
    
    private void showIP() throws UnknownHostException {
         InetAddress inetAddress = InetAddress.getLocalHost();
         System.out.println("IP Address: " + inetAddress.getHostAddress());
         System.out.println("Host Name: " + inetAddress.getHostName());
            
         lbl_no_users.setText("Host Name: " + inetAddress.getHostName());
         jLabel3.setText("IP Address: " + inetAddress.getHostAddress());
    }

     private void showOnlineUsers() throws SQLException {
        tm = new TableManager(tbl_online_users, lbl_no_users);
        tm.addUsers(new DBConfig().getOnlineUsers());
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        sessionButton = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        lbl_no_users = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_online_users = new javax.swing.JTable();
        cont_inv_button1 = new javax.swing.JButton();
        btn_enable = new javax.swing.JButton();
        logout_button = new javax.swing.JButton();
        btn_disable = new javax.swing.JButton();
        user_button = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 153, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("SansSerif", 1, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Library Inventory Mobile Scanner");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        sessionButton.setBackground(new java.awt.Color(0, 0, 153));
        sessionButton.setFont(new java.awt.Font("Arial Narrow", 1, 36)); // NOI18N
        sessionButton.setForeground(new java.awt.Color(255, 255, 255));
        sessionButton.setText("Start New Inventory");
        sessionButton.setToolTipText("");
        sessionButton.setBorderPainted(false);
        sessionButton.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        sessionButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sessionButtonMouseClicked(evt);
            }
        });
        sessionButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sessionButtonActionPerformed(evt);
            }
        });
        jPanel1.add(sessionButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 490, 400, 60));
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 100, -1, -1));

        jLabel3.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel3.setText("IP Address: ");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 610, -1, -1));

        lbl_no_users.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        lbl_no_users.setText("Connected Users");
        jPanel1.add(lbl_no_users, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 340, -1, -1));

        tbl_online_users.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Name", "Permission"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tbl_online_users);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 360, 280, 190));

        cont_inv_button1.setBackground(new java.awt.Color(0, 0, 153));
        cont_inv_button1.setFont(new java.awt.Font("Arial Narrow", 1, 36)); // NOI18N
        cont_inv_button1.setForeground(new java.awt.Color(255, 255, 255));
        cont_inv_button1.setText("Preview Current Inventory");
        cont_inv_button1.setBorderPainted(false);
        cont_inv_button1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cont_inv_button1ActionPerformed(evt);
            }
        });
        jPanel1.add(cont_inv_button1, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 420, 400, 60));

        btn_enable.setBackground(new java.awt.Color(0, 0, 153));
        btn_enable.setFont(new java.awt.Font("Arial Narrow", 1, 36)); // NOI18N
        btn_enable.setForeground(new java.awt.Color(255, 255, 255));
        btn_enable.setText("Enable");
        btn_enable.setBorderPainted(false);
        btn_enable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_enableMouseClicked(evt);
            }
        });
        btn_enable.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_enableActionPerformed(evt);
            }
        });
        jPanel1.add(btn_enable, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 570, 130, 50));

        logout_button.setText("Logout");
        logout_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logout_buttonMouseClicked(evt);
            }
        });
        jPanel1.add(logout_button, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 90, -1, -1));

        btn_disable.setText("Block");
        btn_disable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_disableMouseClicked(evt);
            }
        });
        btn_disable.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_disableActionPerformed(evt);
            }
        });
        jPanel1.add(btn_disable, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 590, -1, -1));

        user_button.setText("View/Add Users");
        user_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                user_buttonActionPerformed(evt);
            }
        });
        jPanel1.add(user_button, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 370, 400, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 800, 640));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void sessionButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sessionButtonActionPerformed
        try {
            new DBConfig().startNewInventory();
            new DBConfig().startNewBarcode();
            Table table = new Table();
            table.show();
            dispose();
        } catch (SQLException ex) {
            Logger.getLogger(IntroSession.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_sessionButtonActionPerformed

    private void sessionButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sessionButtonMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_sessionButtonMouseClicked

    private void cont_inv_button1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cont_inv_button1ActionPerformed
        Table table;
        try {
            table = new Table();
            table.show();
            dispose();
        } catch (SQLException ex) {
            Logger.getLogger(IntroSession.class.getName()).log(Level.SEVERE, null, ex);
        }
            
    }//GEN-LAST:event_cont_inv_button1ActionPerformed

    private void btn_enableActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_enableActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_enableActionPerformed

    private void btn_enableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_enableMouseClicked
        int id = (int) tbl_online_users.getValueAt(tbl_online_users.getSelectedRow(), 0);
        DBConfig dbconfig = new DBConfig();
        try {
            dbconfig.enableUser(id);
        } catch (SQLException ex) {
            Logger.getLogger(IntroSession.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_btn_enableMouseClicked

    private void logout_buttonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logout_buttonMouseClicked
        AdminLogin adminlogin = new AdminLogin();
        adminlogin.show();
        dispose();
    }//GEN-LAST:event_logout_buttonMouseClicked

    private void btn_disableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_disableMouseClicked
        int id = (int) tbl_online_users.getValueAt(tbl_online_users.getSelectedRow(), 0);
        DBConfig dbconfig = new DBConfig();
        try {
            dbconfig.disableUser(id);
        } catch (SQLException ex) {
            Logger.getLogger(IntroSession.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_btn_disableMouseClicked

    private void user_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_user_buttonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_user_buttonActionPerformed

    private void btn_disableActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_disableActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_disableActionPerformed

    public static void main(String args[]) throws UnknownHostException, 
            SQLException {
        final IntroSession intro = new IntroSession();
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new IntroSession().setVisible(true);
                } catch (UnknownHostException ex) {
                    Logger.getLogger(IntroSession.class.getName()).log(Level.SEVERE, null, ex);
                } catch (SQLException ex) {
                    Logger.getLogger(IntroSession.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_disable;
    private javax.swing.JButton btn_enable;
    private javax.swing.JButton cont_inv_button1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbl_no_users;
    private javax.swing.JButton logout_button;
    private javax.swing.JButton sessionButton;
    private javax.swing.JTable tbl_online_users;
    private javax.swing.JButton user_button;
    // End of variables declaration//GEN-END:variables

}
