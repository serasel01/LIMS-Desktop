<?php
   require_once 'Functions.php';    //require once - import php file from local directory [LIMS]
   $response = array();             //response - display or output; array (predefined) only

    if(isset($_GET['op'])){         //isset to check get values of a variable on the operation

      switch($_GET['op']){
         case 'scanBook':
            $db = new Functions();   //creates an object of that (Functions) class

            $permission = $db->checkPermission($_POST['user_id']);

            if(count($permission)<=0){
              $response['error'] = true;
              $response['message'] = 'Disabled account';
            }

            else {
               //using that object, it is used to call a function (scanBook) of that class (Functions)
              if($db->check_scanned($_POST['barcode'])) {
                $db->scanBook($_POST['id'], $_POST['noscanned'], $_POST['isScanned'], $_POST['barcode']); 
                $response['error'] = false;
                $response['message'] = "Book is successfully counted in inventory!";
         
              } else {
                $response['error'] = true;
                $response['message'] = "Book has already been scanned!";
              }
            }

        break;

        case 'checkIP':
            $response['error'] = false;
            $response['message'] = "You are now connected to the Database!";
         
        break;

        case 'signin':
            $db = new Functions();   //creates an object of that (Functions) class

            $users = $db->checkUser($_POST['id'], md5($_POST['password']));

            if(count($users)<=0){
              $response['error'] = true;
              $response['message'] = 'Invalid id or password';
            } else {
              $db->signIn($_POST['id'], md5($_POST['password']));
              $response['error'] = false;
              $response['message'] = 'Sign in Success!';
            }

         break;

         case 'logout':
            $db = new Functions();   //creates an object of that (Functions) class

            $db->logOut($_POST['id']);
            $response['error'] = false;
            $response['message'] = 'Log Out Success!';

         break;

         case 'addBook':
            $db = new Functions();   //creates an object of that (Functions) class

            $permission = $db->checkPermission($_POST['user_id']);

            if(count($permission)<=0){
              $response['error'] = true;
              $response['message'] = 'Disabled account';
            } else {
              //using that object, it is used to call a function (scanBook) of that class (Functions)
              $db->addBook($_POST['title'], $_POST['barcode'], $_POST['call_no'], $_POST['id'], $_POST['section']); 
              $response['error'] = false;
              $response['message'] = "A book has added into the inventory!";
            }

         break;

        case 'get_booklist':
         $db = new Functions();   //creates an object of that (Functions) class

         $permission = $db->checkPermission($_POST['user_id']);

         if(count($permission)<=0){
              $response['error'] = true;
              $response['message'] = 'Disabled account';
          }

          else {
            $booklist = $db->get_booklist($_POST['section']);     //retrieves an array of books (per section)
            $response['error'] = false;
            $response['message'] = "Scan Success";

            if(count($booklist)<=0){
              $response['error'] = true;
              $response['message'] = 'Nothing found in the database!';
            }

            else{
              $response['error'] = false;
              $response['message'] = 'Success!';
              $response['data'] = $booklist;
            }
          }
          
         break;
      }

    }

   echo json_encode($response); //json encode requires array; echo = print in php
?>