<?php
   class Settings {
      private $con;

       function __construct(){                         //assigns values to an object whenever called or made
 
      }

       function connect(){                            //postgresql, in order to connect to database, host, port, dbname, and credentials are needed
           $host        = "host = 127.0.0.1";
            $port        = "port = 5432";
            $dbname      = "dbname = db_inventory";
            $credentials = "user = postgres password=pgadmin";

            $this->con = pg_connect( "$host $port $dbname $credentials");     //"this" means the current object being referenced; pg_connect is the function that connects the database and requires the 4 variables

            if(!$this->con) {
               echo "Error : Unable to open database\n";      //echo means printout
            } 

            return $this->con;        //return the connection
       }
   }
?>