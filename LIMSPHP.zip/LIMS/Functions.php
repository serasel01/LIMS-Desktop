<?php
	class Functions {
	private $con;
	 
	    function __construct(){
	        require_once dirname(__FILE__) . '/Settings.php';
	        $db = new Settings();
	        $this->con = $db->connect();
	    }

	    public function scanBook($id, $noscanned, $isScanned, $barcode){
	    	pg_prepare($this->con,"s1","UPDATE public.tbl_inventory SET no_scanned=$1, \"timestamp\"=now() WHERE id=$2");			//prepare statement
	    	pg_execute($this->con, "s1", array($noscanned, $id));							//puts value in statement and executes that statement

	    	pg_prepare($this->con,"s2","UPDATE public.tbl_barcode SET is_scanned=$1, \"timestamp\"=now() WHERE barcode=$2");
	    	pg_execute($this->con, "s2", array($isScanned, $barcode));
	 	}

	 	public function addBook($title, $barcode, $call_no, $id, $section){
	    	
	    	pg_prepare($this->con,"s1","INSERT INTO public.tbl_inventory(title, section, id, total_no, no_scanned, call_no, \"timestamp\") VALUES ($1, $4, $3, 1, 1, $2, now())");			//prepare statement
	    	pg_execute($this->con, "s1", array($title, $call_no, $id, $section));							

	    	pg_prepare($this->con,"s2","INSERT INTO public.tbl_barcode(barcode, book_id, is_scanned, \"timestamp\") VALUES ($1, $2, 1, now())");
	    	pg_execute($this->con, "s2", array($barcode, $id));
	 	}

	 	public function signIn($id, $password){
	    	pg_prepare($this->con,"s1","UPDATE public.tbl_users SET online_status= '1' WHERE id=$1 AND password=$2");			//prepare statement
	    	pg_execute($this->con, "s1", array($id, $password));							//puts value in statement and executes that statement
	 	}

	 	public function logOut($id){
	    	pg_prepare($this->con,"s1","UPDATE public.tbl_users SET online_status= '0' WHERE id=$1");			//prepare statement
	    	pg_execute($this->con, "s1", array($id));							//puts value in statement and executes that statement
	 	}

	 	public function checkUser($id, $password){
	 		$result = pg_prepare($this->con, "s", 
	 			"SELECT * FROM public.tbl_users WHERE id = $1 AND password = $2");
	 		$result = pg_execute($this->con, "s", array($id, $password));

	 		$user = array();
			
			while ($row = pg_fetch_row($result)) {
	 			$temp = array();
	 			$temp['id'] = $row[0];
	 			array_push($user, $temp);
	 		}

	 		return $user;
	 	}

	 	public function checkPermission($id){
	 		$result = pg_prepare($this->con, "s", 
	 			"SELECT * FROM public.tbl_users WHERE id = $1 AND permission = '1'");
	 		$result = pg_execute($this->con, "s", array($id));

	 		$user = array();
			
			while ($row = pg_fetch_row($result)) {
	 			$temp = array();
	 			$temp['id'] = $row[0];
	 			array_push($user, $temp);
	 		}

	 		return $user;
	 	}

	 	public function get_booklist ($section){
	 		$result = pg_prepare($this->con, "s4", 
	 			"SELECT title, total_no, br.barcode, id, no_scanned, br.is_scanned, call_no 
	 			FROM tbl_inventory AS inv 
	 			INNER JOIN tbl_barcode AS br 
	 			ON br.book_id = inv.id 
	 			WHERE inv.section = $1");
	 		
	 		$result = pg_execute($this->con, "s4", array($section));
	 		$booklist = array();

	 		while ($row = pg_fetch_row($result)) {
	 			$temp = array();
	 			$temp['title'] = $row[0];
	 			$temp['total_no'] = $row[1];
	 			$temp['barcode'] = $row[2];
	 			$temp['id'] = $row[3];
	 			$temp['no_scanned'] = $row[4];
	 			$temp['is_scanned'] = $row[5];
	 			$temp['call_no'] = $row[6];
	 			array_push($booklist, $temp);
	 		}

	 		return $booklist;
	 	}

	 	public function check_scanned($barcode){
	 		$result = pg_prepare($this->con, "s5", 
	 			"SELECT is_scanned FROM tbl_barcode WHERE barcode = $1");
	 		$result = pg_execute($this->con, "s5", array($barcode));
	 		$row = pg_fetch_result($result, 0, 'is_scanned');
	 		return $row == '0';
	 	}

	}
?>